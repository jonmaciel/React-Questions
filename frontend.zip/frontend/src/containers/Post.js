import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loadComments } from '../actions/';

class Post extends Component {
  render() {
    return (
      <div onClick={() => this.props.loadComments(this.props.id)} className="post">
        {this.props.title}
        {
          this.props.comments() &&
          this.props.comments().map((comment, key) => <p key={key}>{comment.id}</p>)
        }

      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  comments: () => {
    const comments = state.comments
    if(!ownProps.commentIds || !Object.keys(comments).length) return undefined;

    return ownProps.commentIds.map(commentId => {
      return comments[commentId]
    })
  }
});

const mapDispatchToProps = dispatch => ({
  loadComments: postId => dispatch(loadComments(postId))
});

export default connect(mapStateToProps, mapDispatchToProps)(Post);
