import React, { Component } from 'react';
import { connect } from 'react-redux';
import { loadAll } from '../actions/';
import Category from './Category';
import '../App.css';

class App extends Component {
  componentDidMount() {
    this.props.loadAll();
  }

  render() {
    return (
      <div className="App">
        <div className="list-posts-content">
          <div className="list-posts-title">
            <h1>Questions</h1>
          </div>

          <div className="list-posts-content">
            {Object.values(this.props.categories).map(category =>
              <Category key={category.path} {...category}/>
            )}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  categories: state.categories
});

const mapDispatchToProps = dispatch => ({
  loadAll: () => dispatch(loadAll())
});

export default connect(mapStateToProps, mapDispatchToProps)(App);
