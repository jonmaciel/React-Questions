import React, { Component } from 'react';
import { connect } from 'react-redux';
import Post from './Post';

class Category extends Component {
  render() {
    return (
      <div className="post-body">
        <h2 className="post-body-title">
          {this.props.name}
        </h2>
        <div className="post-body-posts">
          <ol className="posts-grid">
            {this.props.posts && this.props.posts.map((post, i) =>
              <li key={i}>
                <Post {...post} />
              </li>
            )}
          </ol>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  posts: ownProps.postIds && ownProps.postIds.map(postId => state.posts[postId])
});

const mapDispatchToProps = dispatch => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(Category);
