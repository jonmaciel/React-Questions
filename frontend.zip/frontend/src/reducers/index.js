import { combineReducers } from 'redux';
import * as t from '../actionTypes';

const categories = (state = {}, action) => {
  const { path, categories, postId } = action

  switch (action.type) {

    case t.ADD_CATEGORIES: {
      return {...categories}
    }

    case t.ADD_COMMENT_TO_CATEGORIE: {
      const newCategories = {...state}

      if(newCategories[path].postIds) {
        newCategories[path].postIds = [...newCategories[path].postIds].concat(postId)
      } else {
        newCategories[path].postIds = [postId]
      }

      return {...newCategories}
    }

    default:
      return state;
  }
}

const posts = (state = {}, action) => {
  const { id, post, scoreQuantity, posts, commentId} = action

  switch (action.type) {

    case t.ADD_POSTS: {
      return {...state, ...posts}
    }

    case t.ADD_COMMENT_TO_POST: {
      const newPosts = {...state}

      if(newPosts[id].commentIds) {
        newPosts[id].commentIds = [...newPosts[id].commentIds].concat(commentId)
      } else {
        newPosts[id].commentIds = [commentId]
      }

      return {...newPosts}
    }

    case t.CREATE_POST: {
      let posts = {...state.posts}
      posts[id] = {...post, commentIds: []}

      return {...state, ...posts}
    }

    case t.EDIT_POST: {
      let posts = {...state.posts}
      posts[id] = post

      return {...state, ...posts}
    }

    case t.DELETE_POST: {
      let posts = [...state.posts]
      delete posts[id]

      return {...state, ...posts}
    }

    case t.THUMBS_POST: {
      let posts = {...state.posts}
      posts[id].voteScore += scoreQuantity

      return {...state, ...posts}
    }

    default:
      return state;
  }
};

const comments = (state = {}, action) => {
  const { id, comment, postId, scoreQuantity, comments } = action

  switch (action.type) {
    case t.ADD_COMMENTS: {
      return {...state, ...comments}
    }

    case t.CREATE_COMMENT: {
      let posts = {...state.posts}
      posts[postId].commentIds.push(id)
      let comments = {...state.comments}
      comments[id] = comment

      return {...state, posts, ...comments}
    }

    case t.EDIT_COMMENT: {
      let comments = {...state.comments}
      comments[id] = comment

      return {...state, ...comments}
    }

    case t.DELETE_COMMENT: {
      let posts = {...state.posts}
      posts[postId].commentIds = posts[postId].commentIds.filter(commentsId => commentsId === id)

      let comments = {...state.comments}
      delete comments[id]

      return {...state, posts, ...comments}
    }

    case t.THUMBS_COMMENT: {
      let comments = {...state.comments}
      comments[id].voteScore += scoreQuantity

      return {...state, ...comments}
    }

    default:
      return state;
  }
};

export default combineReducers({ categories,posts, comments });
