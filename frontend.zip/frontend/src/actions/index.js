import * as t from '../actionTypes';
import { url, headers } from '../apiConfig';

export const addCategories = categories => ({ type: t.ADD_CATEGORIES, categories});
export const addCommentToCategorie = (postId, path) => ({ type: t.ADD_COMMENT_TO_CATEGORIE, postId, path});
export const addPosts = posts => ({ type: t.ADD_POSTS, posts })

export const createPost = post => ({ type: t.CREATE_POST, post });
export const editPost = (id, post) => ({ type: t.EDIT_POST, id, post });
export const deletePost = id => ({ type: t.DELETE_POST, id });
export const thumbsUpPost = id => ({ type: t.THUMBS_POST, id, scoreQuantity: 1 });
export const thumbsDownPost = id => ({ type: t.THUMBS_POST, id, scoreQuantity: -1 });

export const addComments = comments => ({ type: t.ADD_COMMENTS, comments});
export const createComment = (postId, comment) => ({ type: t.CREATE_COMMENT, comment });
export const editComment = (id, comment) => ({ type: t.EDIT_COMMENT, id, comment });
export const deleteComment = (id, postId) => ({ type: t.DELETE_COMMENT, id });
export const thumbsUpComment = id => ({ type: t.THUMBS_COMMENT, id, scoreQuantity: 1 });
export const thumbsDownComment = id => ({ type: t.THUMBS_COMMENT, id, scoreQuantity: -1 });
export const addCommentToPost = (id, commentId) => ({ type: t.ADD_COMMENT_TO_POST, id, commentId});

export const loadAll = () => (dispatch, getState) =>
  fetch(`${url}/categories`, { headers })
    .then(res => res.json())
    .then(data => {
      dispatch(addCategories(normalizer(data.categories, 'path')))
    }).then(
      fetch(`${url}/posts`, { headers })
        .then(res => res.json())
        .then(posts => dispatch(addPostInCategory(posts)))
    )

export const loadComments = postId => (dispatch, getState) =>
  fetch(`${url}/posts/${postId}/comments`, { headers })
    .then(res => res.json())
    .then(comments => dispatch(addCommentInPost(comments)))

export const addPostInCategory = posts => (dispatch, getState) => {
  posts.forEach(post =>
    dispatch(addCommentToCategorie(post.id, post.category))
  )
  dispatch(addPosts(normalizer(posts)))
};

export const addCommentInPost = comments => (dispatch, getState) => {
  Object.values(comments).forEach(comment =>
    dispatch(addCommentToPost(comment.parentId, comment.id))
  )

  dispatch(addComments(normalizer(comments)))
};

const normalizer = (colection, idName = 'id') =>
  colection.reduce((newColection, member) => {
    newColection[member[idName]] = member
    return newColection
  }, {})

